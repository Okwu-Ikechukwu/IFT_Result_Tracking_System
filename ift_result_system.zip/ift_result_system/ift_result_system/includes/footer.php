<script>document.querySelectorAll('.portal-menu').forEach(b=>b.addEventListener('click',()=>document.getElementById('sidebar')?.classList.toggle('open')));</script></body></html>
